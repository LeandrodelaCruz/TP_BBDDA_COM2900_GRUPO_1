# Entrega 6 — Importación de `dbo.Jugador` mediante scraping

## 1. Por qué se usa scraping para Jugador

El CSV `squads_and_players.csv` del dataset utilizado anteriormente contiene nombre completo, posición, club y fecha de nacimiento, pero no contiene el dorsal requerido por `dbo.Jugador`.

Para no inventar datos, esta etapa utiliza la página pública:

`https://en.wikipedia.org/wiki/2026_FIFA_World_Cup_squads`

La página publica por jugador el número, posición, nombre, fecha de nacimiento y club. Esto permite además cumplir el requisito de la Entrega 6 que exige que al menos uno de los datasets sea obtenido mediante scraping.

## 2. Flujo

```text
Wikipedia (HTML)
        ↓
Python + BeautifulSoup
        ↓
Archivos_Importacion/jugadores_scraping.csv
        ↓
Docker: /var/opt/mssql/import/jugadores_scraping.csv
        ↓
importacion.SP_Importar_Jugador_Scraping_CSV
        ↓
abm.Jugador_Alta / abm.Jugador_Modificar
        ↓
dbo.Jugador
```

## 3. Ejecutar el scraper

Desde la raíz del proyecto:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r Scraping/requirements.txt
python3 Scraping/01_scrapear_jugadores_wikipedia.py
```

El resultado esperado es:

```text
Archivos_Importacion/jugadores_scraping.csv
```

El script informa cuántas selecciones y jugadores pudo extraer.

## 4. Copiar el archivo al contenedor SQL Server

```bash
docker exec -it sqlserver mkdir -p /var/opt/mssql/import
docker cp Archivos_Importacion/jugadores_scraping.csv \
  sqlserver:/var/opt/mssql/import/jugadores_scraping.csv
```

Verificar:

```bash
docker exec -it sqlserver ls -l /var/opt/mssql/import/jugadores_scraping.csv
docker exec -it sqlserver head -n 5 /var/opt/mssql/import/jugadores_scraping.csv
```

## 5. Crear el SP de importación

Ejecutar:

`Stored_Procedures_Importaciones/03_SP_Importar_Jugador_Scraping_CSV.sql`

Requiere que previamente existan:

- `dbo.Seleccion`
- `dbo.Jugador`
- `abm.Jugador_Alta`
- `abm.Jugador_Modificar`
- esquema `importacion`

## 6. Ejecutar el test

Ejecutar:

`Test/23_Test_Importar_Jugador_Scraping_CSV.sql`

El test importa el mismo archivo dos veces para comprobar el UPSERT y consulta posibles duplicados.

## 7. Regla para nombre y apellido

Wikipedia entrega el nombre completo en un solo campo, mientras que `dbo.Jugador` tiene `nombre` y `apellido` separados.

Regla documentada:

- último término del nombre completo → `apellido`
- todos los términos anteriores → `nombre`

Ejemplo:

```text
José Raúl Rangel
→ nombre: José Raúl
→ apellido: Rangel
```

Si el jugador tiene un solo nombre (monónimo), el importador lo informa como error y continúa. No se inventa un apellido.

## 8. Clave de UPSERT

Se considera el mismo jugador cuando coinciden:

```text
id_seleccion + nombre + apellido + fecha_nacimiento
```

No se usa el dorsal como identidad porque puede cambiar ante reemplazos.
